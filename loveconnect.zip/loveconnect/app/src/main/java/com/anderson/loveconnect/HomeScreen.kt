package com.anderson.loveconnect

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController

@Composable
fun HomeScreen(navController: NavHostController) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Bem-vindo 😏", fontSize = 28.sp)
        Spacer(Modifier.height(16.dp))
        Text("Login concluído com sucesso.")
        Spacer(Modifier.height(24.dp))
        Button(onClick = { navController.navigate("login") }) {
            Text("Sair (voltar login)")
        }
    }
}