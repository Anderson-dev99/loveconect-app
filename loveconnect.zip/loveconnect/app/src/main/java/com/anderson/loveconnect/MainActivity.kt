package com.anderson.loveconnect

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.anderson.loveconnect.ui.theme.LoveconnectTheme
import androidx.navigation.NavHostController


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            LoveconnectTheme {
                    AppNav()
                }


        }
    }
}

@Composable
fun LoginScreen(navController: NavHostController) {

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "LoveConnect ❤️",
            fontSize = 32.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Entre do seu jeito",
            fontSize = 16.sp
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = {
                navController.navigate("sms")
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(text = "Entrar com SMS")
        }

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedButton(
            onClick = {
                navController.navigate("email")
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(text = "Entrar com e-mail e senha")
        }


        Spacer(modifier = Modifier.height(16.dp))

        TextButton(onClick = { }) {
            Text("Criar conta")
        }

        TextButton(onClick = { }) {
            Text("Esqueci minha senha")
        }

    }
    }



@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    LoveconnectTheme {
        Greeting()
    }
}

@Composable
fun Greeting() {
    TODO("Not yet implemented")
}