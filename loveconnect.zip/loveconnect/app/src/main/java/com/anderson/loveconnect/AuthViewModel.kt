package com.anderson.loveconnect

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class AuthViewModel(
    private val repo: AuthRepository = InMemoryAuthRepository()
) : ViewModel() {

    private val _state = MutableStateFlow(AuthState())
    val state: StateFlow<AuthState> = _state

    fun sendOtp(phoneDigits: String) {
        _state.value = _state.value.copy(isLoading = true, error = null)

        repo.sendOtp(phoneDigits)
            .onSuccess { otp ->
                _state.value = _state.value.copy(
                    isLoading = false,
                    isOtpSent = true,
                    phoneDigits = phoneDigits,
                    lastOtp = otp
                )
            }
            .onFailure { e ->
                _state.value = _state.value.copy(
                    isLoading = false,
                    error = e.message ?: "Erro ao enviar OTP"
                )
            }
    }

    fun verifyOtp(phoneDigits: String, otp: String) {
        _state.value = _state.value.copy(isLoading = true, error = null)

        repo.verifyOtp(phoneDigits, otp)
            .onSuccess { ok ->
                _state.value = _state.value.copy(
                    isLoading = false,
                    isVerified = ok,
                    error = if (ok) null else "Código inválido"
                )
            }
            .onFailure { e ->
                _state.value = _state.value.copy(
                    isLoading = false,
                    error = e.message ?: "Erro ao validar código"
                )
            }
    }

    fun consumeOtpSent() {
        _state.value = _state.value.copy(isOtpSent = false)
    }

    fun clearError() {
        _state.value = _state.value.copy(error = null)
    }
}
