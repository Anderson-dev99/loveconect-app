package com.anderson.loveconnect

import kotlin.random.Random

object AuthMock {
    private var currentOtp: String? = null

    fun generate(): String {
        currentOtp = (100000..999999).random().toString()
        return currentOtp!!
    }

    fun validate(otp: String): Boolean {
        return otp == currentOtp
    }

    fun clear() {
        currentOtp = null
    }
}


