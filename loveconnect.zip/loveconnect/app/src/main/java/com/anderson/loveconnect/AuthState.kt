package com.anderson.loveconnect

data class AuthState(
    val isLoading: Boolean = false,
    val error: String? = null,
    val isOtpSent: Boolean = false,
    val isVerified: Boolean = false,
    val phoneDigits: String = "",
    val lastOtp: String? = null // debug/mock
)
