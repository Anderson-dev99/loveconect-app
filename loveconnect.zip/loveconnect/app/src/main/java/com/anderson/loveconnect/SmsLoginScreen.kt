package com.anderson.loveconnect

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.LaunchedEffect


@Composable
fun SmsLoginScreen(navController: NavHostController) {

    var phoneDigits by remember { mutableStateOf("") }
    val vm: AuthViewModel = viewModel()
    val state = vm.state.collectAsState().value

    LaunchedEffect(state.isOtpSent) {
        if (state.isOtpSent) {
            navController.navigate("otp/${state.phoneDigits}")
            vm.consumeOtpSent()
        }
    }


    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "Login por SMS", fontSize = 26.sp)

        Spacer(modifier = Modifier.height(24.dp))

        OutlinedTextField(
            value = phoneDigits,
            onValueChange = { typed ->
                phoneDigits = typed.filter { it.isDigit() }.take(11)
            },
            label = { Text("Número de telefone") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            enabled = phoneDigits.length == 11 && !state.isLoading,
            onClick = { vm.sendOtp(phoneDigits) }
        ) {
            Text("Enviar código")
        }




        Spacer(modifier = Modifier.height(16.dp))

        TextButton(onClick = { navController.popBackStack() }) {
            Text("Voltar")
        }
    }
}

private fun formatPhoneBR(digits: String): String {
    val d = digits.filter { it.isDigit() }.take(11)

    return when {
        d.length <= 2 -> d
        d.length <= 7 -> "(${d.take(2)}) ${d.drop(2)}"
        else -> "(${d.take(2)}) ${d.substring(2, 7)}-${d.drop(7)}"
    }
}
