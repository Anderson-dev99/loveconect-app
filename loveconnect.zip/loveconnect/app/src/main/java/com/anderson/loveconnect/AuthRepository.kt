package com.anderson.loveconnect

interface AuthRepository {
    fun sendOtp(phoneDigits: String): Result<String>
    fun verifyOtp(phoneDigits: String, otp: String): Result<Boolean>
}
