package com.anderson.loveconnect

import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.RoundedCornerShape
import android.view.KeyEvent as AndroidKeyEvent




@Composable
fun OtpBoxes(
    otp: String,
    onOtpChange: (String) -> Unit,
    length: Int = 6
) {
    val requesters = remember { List(length) { FocusRequester() } }

    // garante que otp nunca passe do tamanho
    val safeOtp = otp.take(length)

    LaunchedEffect(Unit) {
        requesters.firstOrNull()?.requestFocus()
    }

    Row(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        repeat(length) { index ->
            val char = safeOtp.getOrNull(index)?.toString() ?: ""

            BasicTextField(
                value = char,
                onValueChange = { typed ->
                    val digit = typed.filter { it.isDigit() }.take(1)

                    // monta a nova string trocando só a posição atual
                    val chars = safeOtp.padEnd(length, ' ').toCharArray()

                    if (digit.isNotEmpty()) {
                        chars[index] = digit[0]
                        val newOtp = String(chars).replace(" ", "").take(length)
                        onOtpChange(newOtp)

                        // vai pro próximo
                        if (index < length - 1) requesters[index + 1].requestFocus()
                    }
                },
                textStyle = TextStyle(
                    fontSize = MaterialTheme.typography.titleLarge.fontSize,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurface
                ),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                modifier = Modifier
                    .size(width = 52.dp, height = 56.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .border(
                        width = 1.dp,
                        color = MaterialTheme.colorScheme.outline,
                        shape = RoundedCornerShape(12.dp)
                    )
                    .focusRequester(requesters[index])
                    .onKeyEvent { event ->
                        val ne = event.nativeKeyEvent
                        if (ne.action == AndroidKeyEvent.ACTION_DOWN && ne.keyCode == AndroidKeyEvent.KEYCODE_DEL) {
                            val currentIsEmpty = safeOtp.getOrNull(index)?.isDigit() != true

                            if (currentIsEmpty && index > 0) {
                                val chars = safeOtp.padEnd(length, ' ').toCharArray()
                                chars[index - 1] = ' '
                                val newOtp = String(chars).replace(" ", "").take(length)
                                onOtpChange(newOtp)
                            }
                            true
                        } else {
                            false
                        }
                    }

                    .focusable(),
                decorationBox = { inner ->
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) { inner() }
                }
            )
        }
    }
}

