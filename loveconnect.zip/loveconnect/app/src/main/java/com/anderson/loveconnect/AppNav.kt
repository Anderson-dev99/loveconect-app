package com.anderson.loveconnect

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

@Composable
fun AppNav() {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = Routes.LOGIN_CHOICE
    ) {
        composable(Routes.LOGIN_CHOICE) {
            LoginChoiceScreen(navController)
        }

        composable(Routes.SMS_LOGIN) {
            SmsLoginScreen(navController)
        }

        composable(Routes.EMAIL_LOGIN) {
            EmailLoginScreen(navController)
        }

        composable(Routes.REGISTER) {
            RegisterScreen(navController)
        }

        composable(Routes.OTP) { backStackEntry ->
            val phoneDigits = backStackEntry.arguments?.getString("phoneDigits") ?: ""
            OtpScreen(navController = navController, phoneDigits = phoneDigits)
        }

        composable(Routes.HOME) {
            HomeScreen(navController)
        }
    }
}








object Routes {
    const val LOGIN_CHOICE = "login_choice"
    const val SMS_LOGIN = "sms_login"
    const val EMAIL_LOGIN = "email_login"
    const val REGISTER = "register"
    const val OTP = "otp/{phoneDigits}"
    fun otp(phoneDigits: String) = "otp/$phoneDigits"
    const val HOME = "home"
}



