package com.anderson.loveconnect

import android.util.Log
import kotlin.random.Random

class InMemoryAuthRepository : AuthRepository {

    private val otpByPhone = mutableMapOf<String, String>()

    override fun sendOtp(phoneDigits: String): Result<String> = runCatching {
        val otp = Random.nextInt(0, 1_000_000)
            .toString()
            .padStart(6, '0')

        otpByPhone[phoneDigits] = otp
        Log.d("OTP", "OTP para $phoneDigits = $otp (mock)")
        otp
    }

    override fun verifyOtp(phoneDigits: String, otp: String): Result<Boolean> = runCatching {
        val expected = otpByPhone[phoneDigits]
        expected == otp
    }
}
