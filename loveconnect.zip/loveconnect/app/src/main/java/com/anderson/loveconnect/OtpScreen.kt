package com.anderson.loveconnect

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.compose.material3.MaterialTheme
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState


@Composable
fun OtpScreen(
    navController: NavHostController,
    phoneDigits: String
) {
    val vm: AuthViewModel = viewModel()
    val state = vm.state.collectAsState().value
    LaunchedEffect(state.isVerified) {
        if (state.isVerified) {
            navController.navigate("home") {
                popUpTo("login") { inclusive = true }
            }
        }
    }

    var otp by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    val canConfirm = otp.length == 6

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {

        OtpBoxes(
            otp = otp,
            onOtpChange = {
                otp = it
                error = null
            }
        )

    }
    Text("Digite o código", fontSize = 26.sp)
    Spacer(Modifier.height(8.dp))
    Text("Enviamos para: $phoneDigits")

    Spacer(Modifier.height(24.dp))

    @Composable
    fun OtpBoxes(
        otp: String,
        onOtpChange: (String) -> Unit,
        length: Int = 6
    ) {
        OutlinedTextField(

            value = otp,
            onValueChange = { typed ->
                if (typed.length <= length && typed.all { it.isDigit() }) {
                    onOtpChange(typed)
                }
            },
            label = { Text("Código ($length dígitos)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )
    }


    Button(
        enabled = canConfirm,
        onClick = {
            if (AuthMock.validate(otp)) {
                navController.navigate("home") {
                    popUpTo("login") { inclusive = true }
                }
            } else {
                error = "Código inválido"
            }
        },
        modifier = Modifier.fillMaxWidth()
    ) {
        Text("Confirmar")
    }

    Spacer(Modifier.height(16.dp))

    TextButton(onClick = { navController.popBackStack() }) {
        Text("Voltar")
    }
}


